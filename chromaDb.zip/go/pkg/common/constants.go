package common

const (
	DefaultTenant   = "default_tenant"
	DefaultDatabase = "default_database"
)
