# These kubernetes manifests are UNDER ACTIVE  DEVELOPMENT and are not yet ready for production use.
# They will be used for the upcoming distributed version of chroma. They are not even ready
# for testing yet. Please do not use them unless you are working on the distributed version of chroma.
